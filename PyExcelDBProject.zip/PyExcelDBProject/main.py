from excel.excel_reader import read_employees_excel
from excel.excel_writer import write_to_excel
from db.connection import get_connection
from db.employee_dao import insert_employees
from db.employee_dao import fetch_employees
from json_data.json_reader import load_db_data


employees = read_employees_excel("C:/DAPRAC/PyExcelDBProject/resource/employees.xlsx")

db_data = load_db_data("C:/DAPRAC/PyExcelDBProject/resource/db_info.json")
connection = get_connection(db_data["MYSQL_HOST"],db_data["MYSQL_USER"], db_data["MYSQL_PASSWORD"],db_data["MYSQL_DB_NAME"])

insert_employees(connection,employees)

db_data = fetch_employees(connection)

write_to_excel(db_data,"C:/DAPRAC/PyExcelDBProject/output_employees.xlsx")

connection.close()

print("Process Completed")
