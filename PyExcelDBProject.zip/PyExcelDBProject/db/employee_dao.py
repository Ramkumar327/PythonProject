def insert_employees(connection, employees):
    cursor = connection.cursor()
    clean_employees(cursor)
    query = "insert into employees(name,email,salary) VALUES(%s,%s,%s);"
    lst_of_tpl_data = [(e["name"],e["email"],e["salary"]) for e in employees]
    cursor.executemany(query,lst_of_tpl_data)
    connection.commit()


def fetch_employees(connection):
    cursor = connection.cursor(dictionary=True)
    cursor.execute("Select * from employees")
    data = cursor.fetchall()
    cursor.close()
    return data

def clean_employees(cursor):
    query = "truncate table employees"
    cursor.execute(query)
