import mysql.connector
from mysql.connector import Error
import sys

def get_connection(host,user,password,database):
    try:
       connection = mysql.connector.connect(
           host=host,
           user=user,
           password=password,
           database=database
       )
       if connection.is_connected():
           print("Connected to MySQL database...")
           cursor = connection.cursor()
           query = "CREATE TABLE IF NOT EXISTS employees(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), email VARCHAR(100), salary INT ); "
           cursor.execute(query)
           connection.commit()
           print(cursor.rowcount)
           return connection

    except Error as e:
       print(f"Error occured due to :: {e}")
       sys.exit(1)