import json

with open("C:/DAPRAC/MyProject/resource/datasheet/JSON/db_info.json") as f:
    data = json.load(f)

MYSQL_HOST = data["MYSQL_HOST"]
MYSQL_USER = data["MYSQL_USER"]
MYSQL_PASSWORD = data["MYSQL_PASSWORD"]
MYSQL_DB_PORT = data["MYSQL_DB_PORT"]
MYSQL_DB_NAME = data["MYSQL_DB_NAME"]
MYSQL_TABLE_NAME = data["MYSQL_TABLE_NAME"]
db_data = data["db_data"]