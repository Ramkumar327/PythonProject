import json

with open("C:/DAPRAC/MyProject/resource/datasheet/JSON/login_credentials.json") as f:
    data = json.load(f)

LOGIN_USERNAME = data["LOGIN_USERNAME"]
LOGIN_PASSWORD = data["LOGIN_PASSWORD"]
