import json

def load_db_data():
    with open("C:/DAPRAC/SeleniumProject/datasheet/JSON/db_info.json","r") as file:
        data = json.load(file)
    return data

def load_login_creds():
    with open("C:/DAPRAC/SeleniumProject/datasheet/JSON/login_credentials.json","r") as file:
        data = json.load(file)
    return data