from openpyxl import load_workbook

def get_url_from_excel():
    wb = load_workbook("C:/DAPRAC/SeleniumProject/datasheet/excel/input.xlsx")
    sheet = wb["Sheet1"]  # wb.active
    url = sheet.cell(1, 1).value
    return url

def write_data_to_excel(lst):
    excel_file = "C:/DAPRAC/SeleniumProject/datasheet/excel/input.xlsx"
    sheet_name = "output"

    wb = load_workbook(excel_file)
    if sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]

        sheet.delete_rows(1,sheet.max_row)

    else:
        sheet = wb.create_sheet(title = sheet_name)

    mylst = []
    for data in lst:
        mylst.append(data.text.split(":"))
    print(mylst)

    sheet.append(["Employee Names"])
    for row in mylst:
        sheet.append(row)
    wb.save(excel_file)




# if __name__ == "__main__":
#     url = get_url_from_excel()
#     print(url)
#
#
#     write_data_to_excel([["Ramkumar"],["Thenmozhi"]])
