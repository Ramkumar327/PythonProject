from selenium import webdriver
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import database
import excel
import read_json


driver = webdriver.Chrome()
url = excel.get_url_from_excel()
driver.get(url)
driver.maximize_window()

db_data =  read_json.load_db_data()
login_data =  read_json.load_login_creds()

wait = WebDriverWait(driver, 10)
element = wait.until(EC.visibility_of_element_located((By.NAME, "username")))
driver.find_element(By.NAME,"username").send_keys(login_data["LOGIN_USERNAME"])
driver.find_element(By.NAME,"password").send_keys(login_data["LOGIN_PASSWORD"])
driver.find_element(By.XPATH,"//button[@type='submit']").click()

time.sleep(5)
driver.find_element(By.XPATH,"//span[text()='Admin']").click()
WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//div[text()='Username']")))
lst = driver.find_elements(By.XPATH, "//div[@class='oxd-table-row oxd-table-row--with-border']/div[4]")

excel.write_data_to_excel(lst[1:])

try:
    connection = database.get_connection(db_data["MYSQL_HOST"], db_data["MYSQL_USER"], db_data["MYSQL_PASSWORD"], db_data["MYSQL_DB_NAME"])
    if connection:
        database.clean_data(connection)
        for data in lst[1:]:
            print(data.text)
            database.insert_record(connection, data.text)
    else:
        print("Connection failed...")
except Exception as e:
    print("Exception occured due to :: ", e)
finally:
    if connection.is_connected():
        connection.close()
        print("Connection has been closed...")


driver.quit()

