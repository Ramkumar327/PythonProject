import pytest

def add(a,b):
    return a + b



@pytest.mark.smoke
# @pytest.mark.skipif(5 > 3, reason="Skipping this test based on condition")
def test_add(setup_teardown):
    try:
        assert add(2,3) == 5
        print("Test passed!")    
    except AssertionError as e:
        print("Test failed!")


@pytest.mark.regression
# @pytest.mark.skip(reason="Skipping this test for now")
@pytest.mark.xfail(reason="Expected failure due to known issue")
def test_sub():
    assert add(5,3) == 6


@pytest.mark.parametrize("a,b,res", [(2,3,5), (1,4,7), (0,0,0)])
def test_manyadds(a,b,res):
    print(f"Testing add({a}, {b}) == {res}")
    assert add(a,b) == res



@pytest.mark.skipif(5 > 3, reason="Skipping this test based on condition")
def test_skip():
    assert add(1,1) == 2    


