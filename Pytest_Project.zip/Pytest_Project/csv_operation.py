import csv


def csv_reader(file_path):
    with open(file_path, mode='r') as file:
        reader = csv.reader(file)
        # next(reader)  # Skip the header row if there is one
        lst = []
        for row in reader:
            lst.append(tuple(map(int, row)))  # Convert each value to int and store as tuple
        return lst