import pytest


@pytest.fixture
def setup_teardown():
    print("Setting up resources.....")
    yield
    print("Tearing down resources.....")
