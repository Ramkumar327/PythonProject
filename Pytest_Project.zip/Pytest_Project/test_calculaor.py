import pytest
from csv_operation import csv_reader



@pytest.mark.parametrize("a,b,expected", csv_reader("test_data.csv"))
@pytest.mark.smoke
def test_addition(a, b, expected):
    try:
        assert a + b == expected
        print(f"Test passed for {a} + {b} = {expected}")
    except AssertionError:
        print(f"Test failed for {a} + {b} = {expected}")
        raise AssertionError(f"Expected {expected} but got {a + b}")